<!DOCTYPE html>
<html>
<head>
  <title>Posting Page</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style_home.css">
</head>

<head>
<style>

body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
h3{
  margin-left: 12%;
}
#clear{
  height: 44px;
  width: 100px;
}
#post{
  margin-left: 80%;
  height: 44px;
  width: 100px;
}
</style>
</head>
<body>
  <?php
  include 'opendb.php';
  
    if(isset($_POST["post"])){
    $post_title=$_POST["post_title"];
    $category=$_POST["category"];
    $content=$_POST["content"];
    $storedFile="images/".basename($_FILES["file"]["name"]);
    move_uploaded_file($_FILES["file"]["tmp_name"],$storedFile);

    $insert_query = mysqli_query($connect,"INSERT INTO tbl_post(post_title,category,content,storedFile) VALUES('$post_title','$category','$content','$storedFile')");

}

  if(isset($_POST["post"])){
    $post_title=$_POST["post_title"];
    $category=$_POST["category"];
    $content=$_POST["content"];
    $storedFile="images/".basename($_FILES["file"]["name"]);
    move_uploaded_file($_FILES["file"]["tmp_name"],$storedFile);

    $view_query=mysqli_query($connect,"SELECT * FROM tbl_post");
          while($row=mysqli_fetch_assoc($view_query))
          {
      header("Location:admin_page.php");
    }
  }
?>
<div class="head">
    
  
  </div>
<div class="topnav">
    
        <a href="admin_page.php" id="left">HOME</a>
          <a href="about.php" >ABOUT</a>
          <a href="post.php" >POST</a>
  
  </div><br>
<h3>What's up?</h3>

<div class="container">
  <form name="post_form" method="post" enctype="multipart/form-data">
    <label for="post_title">News Title: </label>
    <input type="text" id="post_title" name="post_title" placeholder="Enter news title">

    <label for="category">Category: </label>
   
                <label><input type="radio" id="category" name="category" value="Agriculture">Agriculture</label>
                <label><input type="radio" id="category" name="category" value="Transportation">Transportation</label>
                <label><input type="radio" id="category" name="category" value="Weather">Weather</label>
                <label><input type="radio" id="category" name="category" value="Economy">Economy</label>
                <label><input type="radio" id="category" name="category" value="Community">Community</label>
                <label><input type="radio" id="category" name="category" value="Environment">Environment</label>
                <br>
    <label for="content">Content</label>
    <textarea id="content" name="content" placeholder="Write news.." style="height:200px"></textarea>

    <label for="file">Upload Image/s</label>
    <input type="file" name="file" class="btn btn-default btn-file">
    <br>
    <input type="submit" class="btn btn-success" name="post" id="post" value="post">
    <input type="reset" id="clear" class="btn btn-warning" value="clear"> 
             
  </form>
</div>

</body>
</html>