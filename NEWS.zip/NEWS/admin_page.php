<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style_home.css">
</head>
<style>
	
	.container {
  			position: relative;
  			text-align: center;
  			color: black;
		}
</style>
<body>
	
	<div class="head">
		
	
	</div>
	<div class="topnav">
		
				<a href="admin_page.php" id="left">HOME</a>
  				<a href="about.php">ABOUT</a>
  				<a href="post.php">POST</a>
	
	</div><br>
				
			
	<form>

			
			
		<div class="container">

			<?php
					include'opendb.php';

					$view_query=mysqli_query($connect,"SELECT * FROM tbl_post");
					while($row=mysqli_fetch_assoc($view_query))
					{
			
			?>
				<div class="row">
	
				<div class="col-sm-4">
					<img src="<?php echo $row['storedFile'];?>" width="330" height="440" style="opacity: .5px; box-shadow: 0 4px 8px 0 blue, 0 6px 20px 0 lightgray; border: 20px solid white;">
				</div>

				<div class="col-sm-8" style="background-color: rgb(240, 240, 240); padding-bottom: 25px;">

				<h5 style="font-family: Arial; text-align: center; margin-top: 25px;"><label for="post_title"> <h3><?php echo $row["post_title"];?></h3></label></h5>

				<h1 style="color:black; font-family: Georgia; text-align: left;"><em><label for="category"><?php echo $row["category"];?></label><br></em></h1>

		<table>
			<tr>
				<td style="width: 35%; text-align: left; margin-top: 5px; font-size: 17px;">
					
						<label for="content"><p style="text-indent: 5%; text-align: justify;"><?php echo $row ["content"];?></p></label>
					</p>
				</td>
			</tr>
			
				
		</table>
			<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#edit_modal<?php echo $row['id'];?>">Edit</button>
		<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete_modal<?php echo $row['id'];?>">Delete</button>
				</div>

			
		</div>


		<?php include 'modale.php';}?>
		
		<br><br>
		
	</div>


			
	</div></form>
	

</body>
</html>