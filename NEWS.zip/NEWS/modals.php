<?php 
include 'opendb.php';
?>

<div class="modal fade" role="dialog" id="edit_modal<?php echo $row['post_title']?>">
		<div class="modal-dialog">
			<div class="modal-content">
				<!-- MODAL HEADER -->
				<div class="modal-header">
					<h3 class="modal-title">Edit</h3>
					<button type="button" class="close" data-dismiss="modal"> &times; </button>
				</div>
				<!-- MODAL HEADER -->

				<!--MODAL BODY-->
				<div class="modal-body">
					<form method="post" name="supplier_form" enctype="multipart/form-data">
						<div class="form-group">
							 <label for="post_title">News Title: </label>
    						 <input type="text" name="post_title" class="form-control" value="<?php echo $row['post_title'];?>">
						</div>

						<div class="form-group">
							<label for="category">Category: </label>
    						<input type="radio" name="category" value="<?php echo $row["category"];?>">
						</div>

						<div class="form-group">
							<label for="content">Content</label>
    						<input type="content" class="form-control" value="<?php echo $row['content'];?>">
						</div>

						<div class="form-group">
							<label for="file">Upload Image/s</label>
    						<img src="<?php echo $row['storedFile'];?>" width="150" height="100">
   							<input type="text" name="file" class="btn btn-default" value="<?php echo $row['storedFile'];?>">
    						<input type="file" name="file" class="btn btn-default" value="<?php echo $row['storedFile'];?>">
    					</div>

						<div class="form-group">
							<input type="submit" name="update" value="update changes" class="btn btn-success form-control">
						</div>
					</form>
				</div>
				<!--MODAL BODY-->

				<!--MODAL FOOTER-->
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				</div>

				<!--MODAL FOOTER-->

			</div>
		</div>
	</div>