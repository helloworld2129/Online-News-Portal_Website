 <?php
  include 'opendb.php';
  
    
  if(isset($_GET['save']))
{

    $id=$_GET['id'];
    $post_title=$_GET['post_title'];
    $category=$_GET['category'];
    $content=$_GET['content'];
    //$storedFile='images/'.basename($_GET['file']['name']);
    //move_uploaded_file($_FILES['file']['tmp_name'],$storedFile);

    $update_query=mysqli_query($connect,"UPDATE tbl_post SET post_title='$post_title',category='$category',content='$content' WHERE id='$id'"); 
    
}
 if(isset($_POST['delete_post']))
    {
      $id=$_POST['id'];
      mysqli_query($connect,"DELETE from tbl_post WHERE id ='$id'");
    }
?>