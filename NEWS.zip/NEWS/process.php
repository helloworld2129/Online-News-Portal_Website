<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname="db_registration";
	$conn = mysqli_connect($servername,$username,$password,$dbname);

	if (!$conn){
		die("Connection failed: ".mysqli_connect_error());
	}
	if(isset($_POST["submit"])){
    $username=$_POST["username"];
    $password=$_POST["password"];

   $sql = "SELECT * FROM tbl_register WHERE username='".$username."' AND password='".$password."';";
		$result = mysqli_query($conn,$sql);

		if(mysqli_num_rows($result) > 0)
		{
			while($row = $result->fetch_assoc()) 
		 {
    		header("Location:admin_page.php");
 		 }
		} 
		else {
  			echo $remarks="Sorry. Unrecognized username or password. Please try again";
			 }
	}
?>