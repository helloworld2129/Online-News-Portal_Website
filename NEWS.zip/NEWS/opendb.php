
<?php
$connect=mysqli_connect("localhost","root","","db_registration");

	if(!$connect)
	{
		die("Failed connecting to MySQL: ".mysqli_connect_error());

	}

?>`