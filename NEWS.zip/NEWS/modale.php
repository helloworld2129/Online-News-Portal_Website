		<!-- EDIT MODAL BOX -->
		<div class="modal fade" role="dialog" id="edit_modal<?php echo $row['id'];?>">
			<div class="modal-dialog">
				<div class="modal-content">
					<!--MODAL HEADER -->
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h3 class="modal-title">Update News</h3>
						
					</div>
					<!--MODAL HEADER -->

					<!-- MODAL BODY-->
					<div class="modal-body">
						<form method="post" name="post_form" enctype="multipart/form-data">
							
							<div class="form-group">
								
								<!--<label>id</label>-->
								<input type="hidden" readonly name="id" class="form-control" value="<?php echo $row['id'];?>">
							</div>

							<div class="form-group">
								<label>News Title</label>
								<input type="text" name="post_title" class="form-control">
							</div>

							<div class="form-group">
								<label for="category">Category: </label><br>
                				<label><input type="radio" id="category" name="category">Agriculture</label>
                				<label><input type="radio" id="category" name="category" value="Transportation">Transportation</label>
                				<label><input type="radio" id="category" name="category" value="Weather">Weather</label>
                				<label><input type="radio" id="category" name="category" value="Economy">Economy</label>
                				<label><input type="radio" id="category" name="category" value="Community">Community</label>
                				<label><input type="radio" id="category" name="category" value="Environment">Environment</label>
                
							</div>

							<div class="form-group">
								<label>Content</label><br>
								<textarea id="content" name="content" style="height:200px; width: 567px;" value="<?php echo $content; ?>"></textarea>
							</div>
							


							

								<input type="submit" class="btn btn-success" name="save" value="save">
								<input type="reset" id="clear" class="btn btn-warning" value="clear"> 
								<?php include 'update_modale.php';?>
						</form>
					</div>
					<!-- MODAL BODY-->

					<!-- MODAL FOOTER-->
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
					</div>
					<!-- MODAL FOOTER-->
				</div>
			</div>
		</div>
		<!-- EDIT MODAL BOX -->

		<!-- DELETE MODAL BOX -->
		<div class="modal fade" role="dialog" id="delete_modal<?php echo $row['id'];?>">
			<div class="modal-dialog">
				<div class="modal-content">
	
					<!-- MODAL BODY-->
					<div class="modal-body">
						<form method="post" name="post_form">
							<label>Are you sure to delete this post?</label>
							<input type="hidden" name="id" value="<?php echo $row['id'];?>">
							<div class="form-group">
								<input type="submit" name="delete_post" value="Delete" class="btn btn-danger">
								<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
							</div>
						</form>
					</div>
					<!-- MODAL BODY-->

				</div>
			</div>
		</div>
		<!-- DELETE MODAL BOX -->
		<?php include 'update_modale.php';?>