<!DOCTYPE html>
<html>
<head>
	<title>About Page</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style_home.css">
</head>

<style>
	
	

	.services{
		margin: 80px auto;
		text-align: center;
	}

	h1{
		font-family: sans-serif;
		letter-spacing: 1px;
	}


</style>

<body>
	<div class="head">
    
  
  </div>
<div class="topnav">
    
        	<a href="admin_page.php" id="left">HOME</a>
          <a href="about.php" >ABOUT</a>
          <a href="post.php" >POST</a>
  
  </div><br>
	
	<div class="container">
		<div class="services">
			<h1>Our Services</h1>
		</div>
		<div class="row">
			
			<div class="col-md-3 text-center">

				<div class="icon">
					<img src="tel.png" style="height: 30%; width: 30%;">
				</div>
				<h3>Telephone #</h3>
                <p>(075) 632 2013</p>
		    </div>

		    <div class="col-md-3 text-center">

				<div class="icon">
					<img src="globe.png" style="height: 30%; width: 30%;">
				</div>
				<h3>Link</h3>
                <p>http://wwww.dagupan.gov.ph</p>
		    </div>

		    <div class="col-md-3 text-center">

				<div class="icon">
					<img src="about.png" style="height: 30%; width: 30%;">
				</div>
				<h3>About</h3>
                <p>This is the official website of the Dagupan City Public Information Office</p>
		    </div>

		     <div class="col-md-3 text-center">

				<div class="icon">
					<img src="twit.png" style="height: 30%; width: 30%;">
				</div>
				<h3>Twitter</h3>
                <p>http://twitter.com/dagupanpio</p>

		    </div>

	    </div>
	 </div>
	 
</body>
</html>