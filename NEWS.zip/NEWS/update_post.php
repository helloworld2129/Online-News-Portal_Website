<!DOCTYPE html>
<html>
<head>
	<title>Update Details</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style1.css">
</head>

<head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
h3{
	margin-left: 12%;
}
#clear{
	height: 44px;
	width: 100px;
}
#post{
	margin-left: 80%;
	height: 44px;
	width: 100px;
}
</style>
</head>
<body>
 

  
<div class="head">
		<img src="PIO.png" width="200px" height="130px">
		<h2>Public Information Office - Dagupan City</h2>
		<a id="left" href="admin_page.php">Home</a>
		<a href="about.php">About</a>
		<a href="post.php">Post</a>
	</div>
<h3>What's up?</h3>

<div class="container">
  

    <form name="post_form" method="post" enctype="multipart/form-data">
      
    <label for="post_title">News Title: </label>
    <input type="text" id="post_title" name="post_title" placeholder="Enter news title">

    <label for="category">Category: </label>
   
                <label><input type="radio" id="category" name="category" value="Agriculture">Agriculture</label>
                <label><input type="radio" id="category" name="category" value="Transportation">Transportation</label>
                <label><input type="radio" id="category" name="category" value="Weather">Weather</label>
                <label><input type="radio" id="category" name="category" value="Economy">Economy</label>
                <label><input type="radio" id="category" name="category" value="Community">Community</label>
                <label><input type="radio" id="category" name="category" value="Environment">Environment</label>
                <br>
    <label for="content">Content</label>
    <textarea id="content" name="content" placeholder="Write news.." style="height:200px"></textarea>

    <label for="file">Upload Image/s</label>
    <input type="file" name="file" class="btn btn-default btn-file">
    <br>
    <input type="submit" class="btn btn-success" id="save" name="save" value="Save">
    <input type="reset" id="clear" class="btn btn-warning" value="clear"> 
  
  </form>
</div>
  
</body>
</html>