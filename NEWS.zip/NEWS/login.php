<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> Login Page </title>  
<style>   
body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: white;  
}  
button {   
       background-color: #4CAF50;   
       width: 30%;  
        color: white;   
        padding: 15px;   
        margin: 10px 0px;   
        border: none;   
        cursor: pointer;   
         }   
 form {   
        border: 3px solid orange;
        width: 40%;   
    }   
 input[type=text], input[type=password] {   
        width: 50%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid orange;   
        box-sizing: border-box;   
    }  
 button:hover {   
        opacity: 0.7;   
    }   
  .cancelbtn {   
        width: auto;   
        padding: 10px 18px;  
        margin: 10px 5px;
        color: white;  
    }   
        
     
 .container {   
        padding: 25px;   
        background-color: blue;
        color: white;  
    }   
</style>   
</head>   



<body>    
       <center>
    <form action="process.php" method="post">  
        <div class="container"> 
        <center> <img src="PIO.png" style="height: 50%; width: 50%"></center>  
            <label>Username : </label>   
            <input type="text" placeholder="Enter Username" id="username" name="username" required>
            <br>  
            <label>Password : </label>   
            <input type="password" placeholder="Enter Password" id="password" name="password" required>  
            <br>
            <button type="submit" id="submit" name="submit">Login</button>  
            <br> 
             
        </div>   
    </form>
    </center>     
</body>     
</html> 